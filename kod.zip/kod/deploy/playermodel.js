const mongoose = require("mongoose");

const dataSchema = new mongoose.Schema({
  date: {
    required: true,
    type: Date,
  },
  player_id: {
    required: true,
    type: String,
  },
  player_name: {
    required: true,
    type: String,
  },
  villages: {
    required: true,
    type: Array,
  },
});

module.exports = mongoose.model("PlayerData", dataSchema);
