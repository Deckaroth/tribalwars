(function() {
    fetch('https://api.trackitup.pl/api/get/Test3')
        .then(response => response.json())
        .then(data => {
            // Handle the API response data here
            console.log(data);
        })
        .catch(error => {
            // Handle any errors that occurred during the API call
            console.error(error);
        });
})();