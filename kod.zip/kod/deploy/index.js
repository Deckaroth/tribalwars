require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const { router, updateVillageData } = require("./routes");
const cors = require("cors");
const https = require("https");
const fs = require("fs");
const { getData } = require("./utils");
const reportmodel = require("./reportmodel");

const mongoString = process.env.MONGODB_URL;

mongoose.connect(mongoString);
const database = mongoose.connection;

database.on("error", (error) => {
  console.log(error);
});

database.once("connected", () => {
  console.log("Database Connected");

  // reportmodel
  //   .find()
  //   .then((data) => {
  //     data.forEach((report, i) => {
  //       console.log(i);
  //       updateVillageData(report);
  //     });
  //   })
  //   .catch((error) => {
  //     console.log(error);
  //   });
});

var app = express();
app.use(express.json({ limit: "50mb" }));
const allowedOrigins = ["pl197.plemiona.pl", "trackitup.pl"];
app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin) {
        return callback(null, true);
      }

      if (allowedOrigins.includes(origin)) {
        const msg =
          "The CORS policy for this site does not allow access from the specified Origin.";
        return callback(new Error(msg), false);
      }
      return callback(null, true);
    },
  })
);

app.use(express.json());
let httpsServer;

if (process.env.MODE === "development") {
  httpsServer = app.listen(process.env.PORT, () => {
    console.log(`Listening to port ${process.env.PORT} in dev mode`);
  });
} else {
  const privateKey = fs.readFileSync(
    "/etc/letsencrypt/live/api.trackitup.pl/privkey.pem",
    "utf8"
  );
  const certificate = fs.readFileSync(
    "/etc/letsencrypt/live/api.trackitup.pl/cert.pem",
    "utf8"
  );
  const credentials = {
    key: privateKey,
    cert: certificate,
  };
  httpsServer = https
    .createServer(credentials, app)
    .listen(process.env.PORT, () => {
      console.log(`Listening to port ${process.env.PORT}`);
    });
}

app.use("/api", router);
