const mongoose = require("mongoose");

const dataSchema = new mongoose.Schema({
  coord: { type: String, required: true },
  owner: {
    type: {
      updatedAt: { type: Date },
      value: { type: String },
    },
    required: true,
  },
  lastOwnerChange: { type: Date },
  populationBonus: { type: Boolean },
  villageType: {
    updatedAt: { type: Date },
    value: { type: String, enum: ["off", "def", ""] },
  },
  villageUnits: {
    updatedAt: { type: Date },
    value: {
      spear: { type: Number },
      sword: { type: Number },
      axe: { type: Number },
      archer: { type: Number },
      spy: { type: Number },
      light: { type: Number },
      marcher: { type: Number },
      heavy: { type: Number },
      ram: { type: Number },
      catapult: { type: Number },
      knight: { type: Number },
      snob: { type: Number },
    },
  },
  support: {
    updatedAt: { type: Date },
    value: { type: Number },
  },
  wall: {
    updatedAt: { type: Date },
    before: { type: Number },
    after: { type: Number },
  },
  offReturnAt: {
    updatedAt: { type: Date },
    value: { type: Number },
  },
  offKilledAt: { type: Date },
  ownUnits: {
    updatedAt: { type: Date },
    value: {
      spear: { type: Number },
      sword: { type: Number },
      axe: { type: Number },
      archer: { type: Number },
      spy: { type: Number },
      light: { type: Number },
      marcher: { type: Number },
      heavy: { type: Number },
      ram: { type: Number },
      catapult: { type: Number },
      knight: { type: Number },
      snob: { type: Number },
    },
  },
});

module.exports = mongoose.model("VillageModel", dataSchema);
