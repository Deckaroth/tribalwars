const cheerio = require("cheerio");
const fetch = require("node-fetch");

const getHtml = async (url) => {
  const response = await fetch(url);
  return await response.text();
};

const getUnits = (units, offset = 0) => {
  const spear = units
    .find("td")
    .eq(1 + offset)
    .text();
  const sword = units
    .find("td")
    .eq(2 + offset)
    .text();
  const axe = units
    .find("td")
    .eq(3 + offset)
    .text();
  const arch = units
    .find("td")
    .eq(4 + offset)
    .text();
  const spy = units
    .find("td")
    .eq(5 + offset)
    .text();
  const light = units
    .find("td")
    .eq(6 + offset)
    .text();
  const marcher = units
    .find("td")
    .eq(7 + offset)
    .text();
  const heavy = units
    .find("td")
    .eq(8 + offset)
    .text();
  const ram = units
    .find("td")
    .eq(9 + offset)
    .text();
  const catapult = units
    .find("td")
    .eq(10 + offset)
    .text();
  const knight = units
    .find("td")
    .eq(11 + offset)
    .text();
  const snob = units
    .find("td")
    .eq(12 + offset)
    .text();

  if (spear === "") return {};
  return {
    spear,
    sword,
    axe,
    arch,
    spy,
    light,
    marcher,
    heavy,
    ram,
    catapult,
    knight,
    snob,
  };
};

const buildUrl = (id) => `https://pl203.plemiona.pl/public_report/${id}`;

const getData = async (id) => {
  const data = {};
  const $ = cheerio.load(await getHtml(buildUrl(id)));
  const report = $("#ds_body .no_spacing > tbody > tr > td")
    .children("table ")
    .children("tbody")
    .children("tr")
    .children("td");

  data.id = id;
  data.date = report.find("h4").eq(0).text();

  const attackHtml = report.find("#attack_info_att").eq(0);

  const aPlayer = attackHtml.find("tr").eq(0).find("a").text();
  const aVillageRaw = attackHtml.find("tr").eq(1).find("a").text();

  const aVillage = aVillageRaw.slice(-13, -5).replace("(", "").replace(")", "");
  const aUnitsRaw = attackHtml.find("tr").eq(2).find("tbody");

  const aChurch = attackHtml.find("tr").last().text().trim(" ").includes("100%")
    ? true
    : false;
  const aUnitsBefore = aUnitsRaw.find("tr").eq(1);
  const aUnitsAfter = aUnitsRaw.find("tr").eq(2);

  data.attacker = {
    player: aPlayer,
    village: aVillage,
    unitsBefore: getUnits(aUnitsBefore),
    unitsKilled: getUnits(aUnitsAfter),
    faith: aChurch,
  };

  const defHtml = report.find("#attack_info_def").eq(0);

  const dPlayer = defHtml.find("tr").eq(0).find("a").text();
  const dVillageRaw = defHtml.find("tr").eq(1).find("a").text();

  const dVillage = dVillageRaw.slice(-13, -5).replace("(", "").replace(")", "");
  const dUnitsRaw = defHtml.find("tr").eq(2).find("tbody");

  const dChurch = defHtml.find("tr").last().text().trim(" ").includes("100%")
    ? true
    : false;

  const dUnitsBefore = dUnitsRaw.find("tr").eq(1);
  const dUnitsAfter = dUnitsRaw.find("tr").eq(2);
  const awayHtml = report.find("#attack_spy_away").eq(0);

  data.defender = {
    player: dPlayer,
    village: dVillage,
    unitsBefore: getUnits(dUnitsBefore),
    unitsKilled: getUnits(dUnitsAfter),
    away: getUnits(awayHtml.find("tr").eq(1).find("tr").eq(1), -1),
    faith: dChurch,
  };

  const results = report.find("#attack_results").eq(0);
  results.find("tr").each((i, el) => {
    if ($(el).children("th").eq(0).text().includes("Poparcie:")) {
      data.defender.support = $(el)
        .children("td")
        .eq(0)
        .children("b")
        .last()
        .text();
    }
    if (
      $(el).children("th").eq(0).text().includes("Uszkodzenie przez tarany:")
    ) {
      data.defender.wallBefore = $(el)
        .children("td")
        .eq(0)
        .children("b")
        .first()
        .text();
      data.defender.wallAfter = $(el)
        .children("td")
        .eq(0)
        .children("b")
        .last()
        .text();
    }
  });

  return data;
};

module.exports = { getData };
