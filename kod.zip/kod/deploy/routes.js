const express = require("express");
const Model = require("./model");
const AttackModel = require("./attackmodel");
const PlayerModel = require("./playermodel");
const { getData } = require("./utils");
const reportmodel = require("./reportmodel");
const villagemodel = require("./villagemodel");

const router = express.Router();
const formatArrivalDate = (dateString) => {
  if (!dateString) return "null";
  if (dateString.startsWith("dzisiaj")) {
    //get todays date and add the hours and minutes from the string
    const today = new Date();
    const hourString = dateString.replace("dzisiaj o ", "");
    const [hours, minutes, seconds, milliseconds] = hourString.split(":");
    today.setHours(hours);
    today.setMinutes(minutes);
    today.setSeconds(seconds);
    today.setMilliseconds(milliseconds);
    return today.getTime();
  } else if (dateString.startsWith("jutro")) {
    //get tomorrows date and add the hours and minutes from the string
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    const hourString = dateString.replace("jutro o ", "");
    const [hours, minutes, seconds, milliseconds] = hourString.split(":");
    tomorrow.setHours(hours);
    tomorrow.setMinutes(minutes);
    tomorrow.setSeconds(seconds);
    tomorrow.setMilliseconds(milliseconds);
    return tomorrow.getTime();
  } else {
    const dateStringWithoutPrefix = dateString.replace("dnia ", "");
    let date, hourString;

    if (dateStringWithoutPrefix.includes("o")) {
      [date, hourString] = dateStringWithoutPrefix.split(" o ");
    } else {
      [date, hourString] = dateStringWithoutPrefix.split(" ");
    }
    const [day, month, year] = date.split(".");
    const [hours, minutes, seconds, milliseconds] = hourString.split(":");
    const formattedDate = new Date(
      new Date().getFullYear(),
      month - 1,
      day,
      hours,
      minutes,
      seconds,
      milliseconds || 0
    );
    return formattedDate.getTime();
  }
};
const calculteDistance = (origin, target) => {
  const [originX, originY] = origin.split("|");
  const [targetX, targetY] = target.split("|");

  const x = Math.abs(originX - targetX);
  const y = Math.abs(originY - targetY);

  return Math.sqrt(x * x + y * y);
};

const calculateReturnTime = (arrival, distance, isNoble) => {
  const duration = Math.round(distance * (isNoble ? 35 : 30) * 60 * 1000);
  const arrivalAsDate = formatArrivalDate(arrival);
  return arrivalAsDate + duration;
};

const countUnits = (units, countOff = true, countDef = false) => {
  let count = 0;

  if (countDef) count += parseInt(units.spear);
  if (countDef) count += parseInt(units.sword);
  if (countOff) count += parseInt(units.axe);
  if (countDef) count += parseInt(units.arch);
  if (countOff) count += parseInt(units.spy) * 2;
  if (countOff) count += parseInt(units.light) * 4;
  if (countOff) count += parseInt(units.marcher) * 5;
  if (countDef) count += parseInt(units.heavy) * 6;
  if (countOff) count += parseInt(units.catapult) * 8;
  if (countOff) count += parseInt(units.knight) * 10;
  if (countOff) count += parseInt(units.snob) * 100;

  return count;
};

const updateVillageData = (data) => {
  if (!!data.attacker.coord) return;
  const updatedAt = new Date(formatArrivalDate(data.date));
  const distance = calculteDistance(
    data.attacker.village,
    data.defender.village
  );

  const returnTime = calculateReturnTime(
    data.date,
    distance,
    data.attacker.unitsBefore.snob > 0
  );

  const attackerUnitsOff = countUnits(data.attacker.unitsBefore, true, false);
  const isOff = attackerUnitsOff > 1600;

  const attackerVillageObject = {
    coord: data.attacker.village,
    owner: {
      updatedAt,
      value: data.attacker.player,
    },
    populationBonus: countUnits(data.attacker.unitsBefore, true, true) > 21000,
  };

  if (isOff) {
    attackerVillageObject.villageType = { updatedAt, value: "off" };
    if (
      countUnits(data.attacker.unitsKilled, true, false) /
        countUnits(data.attacker.unitsBefore, true, false) >
      0.9
    ) {
      attackerVillageObject.offKilledAt = updatedAt;
    } else {
      attackerVillageObject.offReturnAt = { updatedAt, value: returnTime };
    }
    attackerVillageObject.ownUnits = {
      updatedAt,
      value: {
        spear:
          parseInt(data.attacker.unitsBefore.spear) -
          parseInt(data.attacker.unitsKilled.spear),
        sword:
          parseInt(data.attacker.unitsBefore.sword) -
          parseInt(data.attacker.unitsKilled.sword),
        axe:
          parseInt(data.attacker.unitsBefore.axe) -
          parseInt(data.attacker.unitsKilled.axe),
        arch:
          parseInt(data.attacker.unitsBefore.archer) -
          parseInt(data.attacker.unitsKilled.archer),
        spy:
          parseInt(data.attacker.unitsBefore.spy) -
          parseInt(data.attacker.unitsKilled.spy),
        light:
          parseInt(data.attacker.unitsBefore.light) -
          parseInt(data.attacker.unitsKilled.light),
        marcher:
          parseInt(data.attacker.unitsBefore.marcher) -
          parseInt(data.attacker.unitsKilled.marcher),
        heavy:
          parseInt(data.attacker.unitsBefore.heavy) -
          parseInt(data.attacker.unitsKilled.heavy),
        ram:
          parseInt(data.attacker.unitsBefore.ram) -
          parseInt(data.attacker.unitsKilled.ram),
        catapult:
          parseInt(data.attacker.unitsBefore.catapult) -
          parseInt(data.attacker.unitsKilled.catapult),
        knight:
          parseInt(data.attacker.unitsBefore.knight) -
          parseInt(data.attacker.unitsKilled.knight),
        snob:
          parseInt(data.attacker.unitsBefore.snob) -
          parseInt(data.attacker.unitsKilled.snob),
      },
    };
  }

  villagemodel.findOne({ coord: data.attacker.village }).then((village) => {
    if (village) {
      if (village.owner.updatedAt < attackerVillageObject.owner.updatedAt)
        village.owner = attackerVillageObject.owner;
      if (!village.populationBonus)
        village.populationBonus = attackerVillageObject.populationBonus;
      if (
        !village.villageType?.value ||
        village.villageType?.updatedAt <
          attackerVillageObject.villageType?.updatedAt
      )
        village.villageType = attackerVillageObject.villageType;

      if (
        !village.ownUnits?.value?.spear ||
        village.ownUnits.updatedAt < attackerVillageObject.ownUnits.updatedAt
      )
        village.ownUnits = attackerVillageObject.ownUnits;
      if (
        !village.offReturnAt?.updatedAt ||
        village.offReturnAt?.updatedAt <
          attackerVillageObject.offReturnAt?.updatedAt
      )
        village.offReturnAt = attackerVillageObject.offReturnAt;
      if (
        !village.offKilledAt ||
        village.offKilledAt < attackerVillageObject.offKilledAt
      )
        village.offKilledAt = attackerVillageObject.offKilledAt;

      village.save();
    } else {
      const newVillage = new villagemodel(attackerVillageObject);
      newVillage
        .save()
        .then(() => {
          console.log(
            "Village data updated successfully" + attackerVillageObject.coord
          );
        })
        .catch((error) => {
          console.log(error);
          console.log("Error updating village data");
        });
    }
  });

  let defenderType;
  data.defender.away?.axe && countUnits(data.defender.away, true, false) > 2000
    ? "off"
    : "";
  defenderType =
    defenderType === "" &&
    data.defender.away?.axe &&
    countUnits(data.defender.away, false, true) > 1600
      ? "def"
      : "";

  if (
    !defenderType &&
    data.defender.unitsBefore?.axe &&
    countUnits(data.defender.unitsBefore, true, false) > 11000
  )
    defenderType = "off";

  const defenderVillageObject = {
    coord: data.defender.village,
    owner: {
      updatedAt,
      value: data.defender.player,
    },
  };

  if (data.defender.wallAfter)
    defenderVillageObject.wall = {
      updatedAt,
      before: data.defender.wallBefore,
      after: data.defender.wallAfter,
    };

  if (data.defender.support)
    defenderVillageObject.support = { updatedAt, value: data.defender.support };

  if (data.defender.away?.spear)
    defenderVillageObject.ownUnits = { updatedAt, value: data.defender.away };

  if (data.defender.unitsBefore?.spear)
    defenderVillageObject.villageUnits = {
      updatedAt,
      value: {
        spear:
          parseInt(data.defender.unitsBefore.spear) -
          parseInt(data.defender.unitsKilled.spear),
        sword:
          parseInt(data.defender.unitsBefore.sword) -
          parseInt(data.defender.unitsKilled.sword),
        axe:
          parseInt(data.defender.unitsBefore.axe) -
          parseInt(data.defender.unitsKilled.axe),
        arch:
          parseInt(data.defender.unitsBefore.archer) -
          parseInt(data.defender.unitsKilled.archer),
        spy:
          parseInt(data.defender.unitsBefore.spy) -
          parseInt(data.defender.unitsKilled.spy),
        light:
          parseInt(data.defender.unitsBefore.light) -
          parseInt(data.defender.unitsKilled.light),
        marcher:
          parseInt(data.defender.unitsBefore.marcher) -
          parseInt(data.defender.unitsKilled.marcher),
        heavy:
          parseInt(data.defender.unitsBefore.heavy) -
          parseInt(data.defender.unitsKilled.heavy),
        ram:
          parseInt(data.defender.unitsBefore.ram) -
          parseInt(data.defender.unitsKilled.ram),
        catapult:
          parseInt(data.defender.unitsBefore.catapult) -
          parseInt(data.defender.unitsKilled.catapult),
        knight:
          parseInt(data.defender.unitsBefore.knight) -
          parseInt(data.defender.unitsKilled.knight),
        snob:
          parseInt(data.defender.unitsBefore.snob) -
          parseInt(data.defender.unitsKilled.snob),
      },
    };

  if (defenderType)
    defenderVillageObject.villageType = {
      updatedAt,
      value: data.defender.villageType,
    };

  if (
    data.defender.unitsKilled?.axe &&
    countUnits(data.defender.unitsKilled, true, false) > 15000
  )
    defenderVillageObject.offKilledAt = updatedAt;

  villagemodel.findOne({ coord: data.defender.village }).then((village) => {
    if (village) {
      if (village.owner.updatedAt < defenderVillageObject.owner.updatedAt)
        village.owner = defenderVillageObject.owner;
      if (!village.villageType || village.villageType.updatedAt < updatedAt)
        village.villageType = defenderVillageObject.villageType;
      if (
        !village.villageUnits?.value?.spear ||
        village.villageUnits?.updatedAt <
          defenderVillageObject.villageUnits?.updatedAt
      )
        village.villageUnits = defenderVillageObject.villageUnits;
      if (
        defenderVillageObject.support &&
        (!village.support ||
          village.support?.updatedAt < defenderVillageObject.support?.updatedAt)
      )
        village.support = defenderVillageObject.support;
      if (
        defenderVillageObject.wall &&
        (!village.wall ||
          village.wall?.updatedAt < defenderVillageObject.wall?.updatedAt)
      )
        village.wall = defenderVillageObject.wall;
      if (
        !village.offKilledAt ||
        village.offKilledAt < defenderVillageObject.offKilledAt
      )
        village.offKilledAt = defenderVillageObject.offKilledAt;

      village.save();
    } else {
      const newVillage = new villagemodel(defenderVillageObject);
      newVillage
        .save()
        .then(() => {
          console.log(
            "Village data updated successfully" + defenderVillageObject.coord
          );
        })
        .catch((error) => {
          console.log(error);
          console.log("Error updating village data");
        });
    }
  });
};

// Login route
router.post("/login", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // Perform authentication logic here

  // Example response
  if (username === "admin" && password === "admin") {
    res.send("Login successful");
  } else {
    res.status(401).send("Invalid credentials");
  }
});
//Post Method
router.post("/post", (req, res) => {
  const name = req.body.savedNetworkGroup;
  const data = req.body.data;

  Model.findOne({ name })
    .then((existingData) => {
      if (existingData) {
        // Entry with the same name already exists, update it
        existingData.data = data;
        existingData
          .save()
          .then(() => {
            res.send("Entry updated successfully");
          })
          .catch((error) => {
            res.status(500).send("Error updating entry");
          });
      } else {
        // Entry with the same name doesn't exist, create a new one
        const newData = new Model({
          name,
          data,
        });
        newData
          .save()
          .then(() => {
            res.send("Entry created successfully");
          })
          .catch((error) => {
            res.status(500).send("Error creating entry");
          });
      }
    })
    .catch((error) => {
      res.status(500).send("Error finding existing entry");
    });
});

router.post("/incomings", (req, res) => {
  const name = req.body.playerName;
  const data = req.body.attackArray;

  AttackModel.findOne({ name })
    .then((existingData) => {
      if (existingData) {
        // Entry with the same name already exists, update it
        existingData.data = data;
        existingData
          .save()
          .then(() => {
            res.send("Entry updated successfully");
          })
          .catch((error) => {
            res.status(500).send("Error updating entry");
          });
      } else {
        // Entry with the same name doesn't exist, create a new one
        const newData = new AttackModel({
          name,
          data,
        });
        newData
          .save()
          .then(() => {
            res.send("Entry created successfully");
          })
          .catch((error) => {
            res.status(500).send("Error creating entry");
          });
      }
    })
    .catch((error) => {
      res.status(500).send("Error finding existing entry");
    });
});

router.get("/incomings", (req, res) => {
  AttackModel.find()
    .then((data) => {
      res.json(data);
    })
    .catch((error) => {
      res.status(500).send("Error getting data");
    });
});

router.get("/incomings/:name", (req, res) => {
  AttackModel.find({ name: req.params.name })
    .then((data) => {
      res.json(data);
    })
    .catch((error) => {
      res.status(500).send("Error getting data");
    });
});

router.post("/playerInfo", (req, res) => {
  PlayerModel.findOne({ player_id: req.body.player_id })
    .then((existingData) => {
      if (existingData) {
        // Entry with the same name already exists, update it
        existingData.villages = req.body.villages;
        existingData.date = new Date();
        existingData
          .save()
          .then(() => {
            res.send("Entry updated successfully");
          })
          .catch((error) => {
            res.status(500).send("Error updating entry");
          });
      } else {
        // Entry with the same name doesn't exist, create a new one
        const newData = new PlayerModel({
          date: new Date(),
          player_id: req.body.player_id,
          player_name: req.body.player_name,
          villages: req.body.villages,
        });
        newData
          .save()
          .then(() => {
            res.send("Entry created successfully");
          })
          .catch((error) => {
            console.log(error);
            res.status(500).send("Error creating entry");
          });
      }
    })
    .catch((error) => {
      console.log(error);
      res.status(500).send("Error finding existing entry");
    });
});

router.get("/playerInfo", (req, res) => {
  PlayerModel.find()
    .then((data) => {
      res.json(data);
    })
    .catch((error) => {
      res.status(500).send("Error getting data");
    });
});

router.post("/reports", async (req, res) => {
  const reportId = req.body.reportId;
  const data = await getData(reportId);
  console.log(reportId);
  reportmodel.findOne({ id: reportId }).then((existingData) => {
    if (existingData) {
    } else {
      updateVillageData(data);
      // Entry with the same name doesn't exist, create a new one
      updateVillageData(data);
      const newData = new reportmodel(data);
      newData
        .save()
        .then(() => {
          res.send("Entry created successfully");
        })
        .catch((error) => {
          res.status(500).send("Error creating entry");
        });
    }
  });
});

router.get("/reports", (req, res) => {
  reportmodel
    .find()
    .then((data) => {
      res.json(data);
    })
    .catch((error) => {
      res.status(500).send("Error getting data");
    });
});

router.get("/reports/:coord", (req, res) => {
  const coords = req.params.coord;

  reportmodel
    .find({ "defender.village": coords })
    .then((data) => {
      console.log(data);
      res.json(data);
    })
    .catch((error) => {
      res.status(500).send("Error getting data");
    });
});

//Get all Method
router.get("/get", async (req, res) => {
  const data = await Model.find();
  res.json(data);
});

//Get by ID Method
router.get("/get/:name", async (req, res) => {
  const data = await Model.find({ name: req.params.name });
  res.json(data);
});

//Update by ID Method
router.patch("/update/:id", (req, res) => {
  res.send("Update by ID API");
});

//Delete by ID Method
router.delete("/delete/:id", (req, res) => {
  res.send("Delete by ID API");
});

router.get("/villages", (req, res) => {
  villagemodel
    .find()
    .then((data) => {
      res.json(data);
    })
    .catch((error) => {
      res.status(500).send("Error getting data");
    });
});

router.get("/villages/:coord", (req, res) => {
  const coords = req.params.coord;

  villagemodel
    .find({ coord: coords })
    .then((data) => {
      res.json(data);
    })
    .catch((error) => {
      res.status(500).send("Error getting data");
    });
});

router.post("/villages", (req, res) => {
  const data = req.body;

  villagemodel.findOne({ coord: data.coord }).then((existingData) => {
    if (existingData) {
      // Entry with the same name already exists, update it
      if (data.owner)
        existingData.owner = { updatedAt: new Date(), value: data.owner };
      if (data.populationBonus && !existingData.populationBonus)
        existingData.populationBonus = data.populationBonus;
      if (data.villageType)
        existingData.villageType = {
          updatedAt: new Date(),
          value: data.villageType,
        };
      existingData
        .save()
        .then(() => {
          res.send("Entry updated successfully");
        })
        .catch((error) => {
          res.status(500).send("Error updating entry");
        });
    } else {
      // Entry with the same name doesn't exist, create a new one
      const newData = new villagemodel({
        owner: { updatedAt: new Date(), value: data.owner },
        coord: data.coord,
        populationBonus: data.populationBonus,
        villageType: { updatedAt: new Date(), value: data.villageType },
      });
      newData
        .save()
        .then(() => {
          res.send("Entry created successfully");
        })
        .catch((error) => {
          res.status(500).send("Error creating entry");
        });
    }
  });
});

module.exports = { router, updateVillageData };
