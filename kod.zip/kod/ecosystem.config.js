module.exports = {
  apps : [{
    name   : "Tribaler",
    script : "PORT=3000 npm run start"
  }]
}
