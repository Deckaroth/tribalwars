const mongoose = require("mongoose");

const dataSchema = new mongoose.Schema({
  dateAdded: { type: Date, required: true },
  id: { type: String, required: true },
  date: { type: String, required: true },
  sender: { type: String, required: false },
  attacker: {
    player: String,
    village: String,
    unitsBefore: {
      spear: String,
      sword: String,
      axe: String,
      arch: String,
      spy: String,
      light: String,
      marcher: String,
      heavy: String,
      ram: String,
      catapult: String,
      knight: String,
      snob: String,
    },
    unitsKilled: {
      spear: String,
      sword: String,
      axe: String,
      arch: String,
      spy: String,
      light: String,
      marcher: String,
      heavy: String,
      ram: String,
      catapult: String,
      knight: String,
      snob: String,
    },
    faith: Boolean,
  },
  defender: {
    player: String,
    village: String,
    unitsBefore: Object,
    unitsKilled: Object,
    away: Object,
    faith: Boolean,
    wallBefore: String,
    wallAfter: String,
  },
});

module.exports = mongoose.model("ReportModel", dataSchema);
