module.exports.Token = require('./token.model');
module.exports.User = require('./user.model');
module.exports.Comment = require('./comment.model');
module.exports.Game = require('./game.model');
module.exports.Rating = require('./rating.model');
module.exports.Score = require('./score.model');
